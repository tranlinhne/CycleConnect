﻿<?php
session_start();
include_once __DIR__ . '/config.php';

$error = '';
$success = '';

$email = $_SESSION['reset_email'] ?? '';
$demoCode = $_SESSION['reset_code_demo'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $code = trim($_POST['code'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($email === '' || $code === '' || $new_password === '' || $confirm_password === '') {
        $error = 'Vui lòng nhập đầy đủ thông tin.';
    } elseif ($code !== $demoCode) {
        $error = 'Mã xác nhận không đúng.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Xác nhận mật khẩu không khớp.';
    } elseif (strlen($new_password) < 6) {
        $error = 'Mật khẩu mới phải có ít nhất 6 ký tự.';
    } else {
        $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashedPassword, $email);

        if ($stmt->execute()) {
            unset($_SESSION['reset_email']);
            unset($_SESSION['reset_code_demo']);
            header("Location: login.php?reset=1");
            exit();
        } else {
            $error = 'Không cập nhật được mật khẩu.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đặt lại mật khẩu - GreenRide</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<div class="auth-wrapper">
    <div class="auth-box auth-register">
        <h1 class="auth-title">Đặt lại mật khẩu</h1>
        <p class="auth-subtitle">Nhập mã xác nhận và mật khẩu mới.</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>
        <?php if (!empty($demoCode)): ?>
            <div class="alert alert-success">Mã demo của bạn là: <?= htmlspecialchars($demoCode) ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="email">Email:</label>
                <input
                    id="email"
                    type="email"
                    name="email"
                    required
                    value="<?= htmlspecialchars($email) ?>"
                    placeholder="Nhập email"
                >
            </div>

            <div class="form-group">
                <label for="code">Mã xác nhận:</label>
                <input
                    id="code"
                    type="text"
                    name="code"
                    required
                    placeholder="Nhập mã xác nhận"
                >
            </div>

            <div class="form-group">
                <label for="new_password">Mật khẩu mới:</label>
                <input
                    id="new_password"
                    type="password"
                    name="new_password"
                    required
                    placeholder="Nhập mật khẩu mới"
                >
            </div>

            <div class="form-group">
                <label for="confirm_password">Xác nhận mật khẩu mới:</label>
                <input
                    id="confirm_password"
                    type="password"
                    name="confirm_password"
                    required
                    placeholder="Nhập lại mật khẩu mới"
                >
            </div>

            <button type="submit" class="auth-btn">Đổi mật khẩu</button>

            <div class="auth-text">
                <a href="login.php">Quay lại đăng nhập</a>
            </div>
        </form>
    </div>
</div>

</body>
</html>